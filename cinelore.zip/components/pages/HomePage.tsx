import React, { useRef, useState, useEffect } from 'react';
import { Show, Theory } from '../../types';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { getFullPosterUrl } from '../../services/tmdbService';
import { mockForumService } from '../../services/mockForumService';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import PremiumHero from '../PremiumHero';
import TrendingSection from '../TrendingSection';

interface HomePageProps {
    trendingShows: Show[];
}

const HomePage: React.FC<HomePageProps> = ({ trendingShows }) => {
    const top10ScrollRef = useRef<HTMLDivElement>(null);
    const navigate = useNavigate();
    const [trendingTheories, setTrendingTheories] = useState<Theory[]>([]);

    useEffect(() => {
        const loadTheories = async () => {
            const theories = await mockForumService.getTrendingTheories();
            setTrendingTheories(theories);
        };
        loadTheories();
    }, []);

    // Derived state
    const top10Shows = trendingShows.slice(0, 10);
    const movies = trendingShows.filter(s => s.type === 'movie');
    const series = trendingShows.filter(s => s.type === 'tv');
    const anime = trendingShows.filter(s => s.type === 'anime');
    const manga = trendingShows.filter(s => s.type === 'manga');

    const handleSelectShow = (show: Show) => {
        navigate(`/hub/${show.type}/${show.id}`);
    };

    const handleSelectTheory = (theory: Theory) => {
        if (theory.show_type && theory.show_id) {
            navigate(`/hub/${theory.show_type}/${theory.show_id}?theoryId=${theory.id}`);
        }
    };

    const scroll = (ref: React.RefObject<HTMLDivElement | null>, direction: 'left' | 'right') => {
        if (ref.current) {
            const scrollAmount = direction === 'left' ? -400 : 400;
            ref.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        }
    };

    return (
        <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-4"
        >
            <PremiumHero
                shows={trendingShows}
                trendingTheories={trendingTheories}
                onSelectTheory={handleSelectTheory}
                onSelectShow={handleSelectShow}
            />

            <div className="space-y-10 md:space-y-16 px-6 relative z-10 pb-20">
                {/* TOP 10 Section */}
                <section className="space-y-6">
                    <div className="flex items-center gap-4 px-2 mb-6">
                        <div className="w-1 h-8 bg-white" />
                        <h2 className="text-3xl font-bold text-white tracking-widest uppercase">
                            Top 10 Today
                        </h2>
                    </div>

                    <div className="relative group">
                        {/* Left Arrow */}
                        <button
                            onClick={() => scroll(top10ScrollRef, 'left')}
                            className="absolute left-0 top-0 bottom-0 z-20 w-16 bg-gradient-to-r from-[#0B0C10] to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-start pl-4"
                        >
                            <ChevronLeft className="w-8 h-8 text-white/50 hover:text-white transition-colors" />
                        </button>

                        {/* Scrollable Container */}
                        <div
                            ref={top10ScrollRef}
                            className="flex gap-6 overflow-x-auto scrollbar-hide scroll-smooth px-8 pb-8"
                            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                        >
                            {top10Shows.map((show, index) => (
                                <div
                                    key={show.id}
                                    onClick={() => handleSelectShow(show)}
                                    className="flex-shrink-0 relative cursor-pointer group/card flex items-end w-[200px] md:w-[260px] h-[300px] md:h-[360px]"
                                >
                                    {/* Minimalist Wireframe Number */}
                                    <div className="absolute -left-2 bottom-0 z-0 flex items-end justify-start pointer-events-none">
                                        <span
                                            className="text-[120px] md:text-[140px] leading-[0.8] font-black text-transparent select-none transition-all duration-500 group-hover/card:text-white/5"
                                            style={{
                                                fontFamily: 'system-ui, -apple-system, sans-serif',
                                                WebkitTextStroke: '2px rgba(255,255,255,0.2)'
                                            }}
                                        >
                                            {index + 1}
                                        </span>
                                    </div>

                                    {/* Clean Poster Card - Larger */}
                                    <div className="absolute right-0 top-0 bottom-6 w-[75%] z-10 transition-all duration-500 ease-out group-hover/card:scale-105 group-hover/card:shadow-[0_20px_40px_-10px_rgba(0,0,0,0.5)]">
                                        <div className="w-full h-full rounded-md overflow-hidden bg-slate-900 shadow-2xl">
                                            <img
                                                src={getFullPosterUrl(show.posterPath)}
                                                alt={show.title}
                                                className="w-full h-full object-cover opacity-90 group-hover/card:opacity-100 transition-opacity duration-500 grayscale-[20%] group-hover/card:grayscale-0"
                                            />
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {/* Right Arrow */}
                        <button
                            onClick={() => scroll(top10ScrollRef, 'right')}
                            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-12 h-full bg-gradient-to-l from-[#0B0C10] to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-end pr-2"
                        >
                            <ChevronRight className="w-8 h-8 text-white" />
                        </button>
                    </div>
                </section>

                {/* Stacked Trending Sections */}
                <div id="trending-section" className="space-y-12">
                    {movies.length > 0 && <TrendingSection title="Trending Movies" shows={movies} onSelect={handleSelectShow} />}
                    {series.length > 0 && <TrendingSection title="Trending Series" shows={series} onSelect={handleSelectShow} />}
                    {anime.length > 0 && <TrendingSection title="Trending Anime" shows={anime} onSelect={handleSelectShow} />}
                    {manga.length > 0 && <TrendingSection title="Trending Manga" shows={manga} onSelect={handleSelectShow} />}
                </div>
            </div>
        </motion.div>
    );
};

export default HomePage;
