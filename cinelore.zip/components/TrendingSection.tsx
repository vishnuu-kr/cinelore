import React, { useRef } from 'react';
import { Show } from '../types';
import { getFullPosterUrl } from '../services/tmdbService';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface TrendingSectionProps {
    title: string;
    shows: Show[];
    onSelect: (show: Show) => void;
}

const TrendingSection: React.FC<TrendingSectionProps> = ({ title, shows, onSelect }) => {
    const scrollRef = useRef<HTMLDivElement>(null);

    const scroll = (direction: 'left' | 'right') => {
        if (scrollRef.current) {
            const { current } = scrollRef;
            const scrollAmount = direction === 'left' ? -400 : 400;
            current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        }
    };

    return (
        <section className="space-y-4">
            <div className="flex items-center gap-4 px-2">
                <div className="w-1 h-6 bg-red-600 rounded-full" />
                <h2 className="text-2xl font-bold text-white tracking-wide">{title}</h2>
            </div>

            <div className="relative group">
                {/* Left Arrow */}
                <button
                    onClick={() => scroll('left')}
                    className="absolute left-0 top-0 bottom-0 z-10 w-12 bg-gradient-to-r from-[#0B0C10] to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-start pl-2"
                >
                    <ChevronLeft className="w-8 h-8 text-white" />
                </button>

                {/* Scroll Container */}
                <div
                    ref={scrollRef}
                    className="flex gap-4 overflow-x-auto scrollbar-hide scroll-smooth px-2 pb-4"
                    style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                >
                    {shows.map((show) => (
                        <div
                            key={show.id}
                            onClick={() => onSelect(show)}
                            className="flex-shrink-0 relative w-32 md:w-44 cursor-pointer group/card"
                        >
                            <div className="aspect-[2/3] rounded-lg overflow-hidden shadow-lg transition-transform duration-300 group-hover/card:scale-105">
                                <img
                                    src={getFullPosterUrl(show.posterPath)}
                                    alt={show.title}
                                    className="w-full h-full object-cover"
                                />
                                <div className="absolute inset-0 bg-black/20 group-hover/card:bg-transparent transition-colors" />
                            </div>
                            <h3 className="mt-2 text-sm font-medium text-slate-300 group-hover/card:text-white truncate">
                                {show.title}
                            </h3>
                        </div>
                    ))}
                </div>

                {/* Right Arrow */}
                <button
                    onClick={() => scroll('right')}
                    className="absolute right-0 top-0 bottom-0 z-10 w-12 bg-gradient-to-l from-[#0B0C10] to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-end pr-2"
                >
                    <ChevronRight className="w-8 h-8 text-white" />
                </button>
            </div>
        </section>
    );
};

export default TrendingSection;
