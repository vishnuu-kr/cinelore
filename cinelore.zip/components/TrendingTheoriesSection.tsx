﻿import React, { useRef } from 'react';
import { Theory } from '../types';
import { ChevronLeft, ChevronRight, MessageSquare, ArrowBigUp, Award, CheckCircle, XCircle, ShieldCheck } from 'lucide-react';
import { motion } from 'framer-motion';

interface TrendingTheoriesSectionProps {
    theories: Theory[];
    onSelect: (theory: Theory) => void;
}

const TrendingTheoriesSection: React.FC<TrendingTheoriesSectionProps> = ({ theories, onSelect }) => {
    const scrollRef = useRef<HTMLDivElement>(null);

    const scroll = (direction: 'left' | 'right') => {
        if (scrollRef.current) {
            const { current } = scrollRef;
            const scrollAmount = direction === 'left' ? -400 : 400;
            current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        }
    };

    const getStatusBadge = (theory: Theory) => {
        if (theory.verified_by_expert) {
            return (
                <div className="flex items-center gap-1.5 px-2 py-1 bg-red-500/20 text-red-300 rounded-md ring-1 ring-red-500/40">
                    <ShieldCheck className="w-3 h-3" />
                    <span className="text-[10px] uppercase font-bold tracking-wider">Expert Verified</span>
                </div>
            );
        }
        switch (theory.status) {
            case 'confirmed':
                return (
                    <div className="flex items-center gap-1.5 px-2 py-1 bg-green-500/20 text-green-300 rounded-md ring-1 ring-green-500/40">
                        <CheckCircle className="w-3 h-3" />
                        <span className="text-[10px] uppercase font-bold tracking-wider">Confirmed</span>
                    </div>
                );
            case 'debunked':
                return (
                    <div className="flex items-center gap-1.5 px-2 py-1 bg-red-500/20 text-red-300 rounded-md ring-1 ring-red-500/40">
                        <XCircle className="w-3 h-3" />
                        <span className="text-[10px] uppercase font-bold tracking-wider">Debunked</span>
                    </div>
                );
            default: // active
                return (
                    <div className="flex items-center gap-1.5 px-2 py-1 bg-yellow-500/10 text-yellow-500 rounded-md ring-1 ring-yellow-500/20">
                        <span className="relative flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-yellow-500"></span>
                        </span>
                        <span className="text-[10px] uppercase font-bold tracking-wider">Discussing</span>
                    </div>
                );
        }
    };

    return (
        <section className="space-y-6 py-4">
            <div className="flex items-center justify-between px-2">
                <div className="flex items-center gap-4">
                    <div className="w-1 h-8 bg-gradient-to-b from-red-500 to-red-700 rounded-full" />
                    <div>
                        <h2 className="text-2xl font-black text-white tracking-tight">Trending Theories</h2>
                        <p className="text-xs text-slate-400 font-medium uppercase tracking-widest">Community Intelligence</p>
                    </div>
                </div>
            </div>

            <div className="relative group">
                {/* Left Arrow */}
                <button
                    onClick={() => scroll('left')}
                    className="absolute left-0 top-0 bottom-0 z-20 w-16 bg-gradient-to-r from-[#0B0C10] to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-start pl-2"
                >
                    <ChevronLeft className="w-8 h-8 text-white/70 hover:text-white" />
                </button>

                {/* Cards Container */}
                <div
                    ref={scrollRef}
                    className="flex gap-4 md:gap-6 overflow-x-auto scrollbar-hide scroll-smooth px-6 md:px-2 pb-8 pt-4"
                    style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                >
                    {theories.map((theory) => (
                        <motion.div
                            key={theory.id}
                            onClick={() => onSelect(theory)}
                            whileHover={{ y: -8, scale: 1.02 }}
                            className="flex-shrink-0 w-[85vw] md:w-80 relative flex flex-col bg-[#16181e] border border-white/5 rounded-2xl overflow-hidden cursor-pointer shadow-xl group/card hover:shadow-red-500/20 hover:border-red-500/40 transition-all duration-300"
                        >
                            {/* Card Header (Image or Gradient) */}
                            <div className="h-40 relative overflow-hidden">
                                {theory.image_url ? (
                                    <>
                                        <img
                                            src={theory.image_url}
                                            alt={theory.title}
                                            className="w-full h-full object-cover transition-transform duration-700 group-hover/card:scale-110"
                                        />
                                        <div className="absolute inset-0 bg-gradient-to-t from-[#16181e] to-transparent opacity-80" />
                                    </>
                                ) : (
                                    <div className="w-full h-full bg-gradient-to-br from-red-900 via-red-950 to-[#16181e]">
                                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover/card:opacity-20 transition-opacity">
                                            <MessageSquare className="w-16 h-16 text-red-400" />
                                        </div>
                                    </div>
                                )}

                                <div className="absolute top-3 right-3 z-10">
                                    <span className="px-2 py-1 rounded-md text-[10px] font-bold text-white/90 bg-black/40 border border-white/10 backdrop-blur-md shadow-sm">
                                        {theory.show_title}
                                    </span>
                                </div>
                            </div>

                            {/* Card Content */}
                            <div className="p-5 flex-1 flex flex-col justify-between -mt-2 relative z-10">
                                <div className="space-y-3">
                                    <div className="flex justify-between items-start">
                                        {getStatusBadge(theory)}
                                        {theory.is_bounty && (
                                            <div className="flex items-center gap-1 text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-full border border-amber-400/20" title={`Bounty: ${theory.bounty_reward}`}>
                                                <Award className="w-3 h-3 fill-current" />
                                                <span className="text-[10px] font-bold uppercase">{theory.bounty_reward?.split(' ')[0]}</span>
                                            </div>
                                        )}
                                    </div>

                                    <h3 className="text-lg font-bold text-slate-100 leading-snug line-clamp-2 group-hover/card:text-red-400 transition-colors drop-shadow-sm">
                                        {theory.title}
                                    </h3>

                                    <p className="text-sm text-slate-400 line-clamp-2 leading-relaxed font-medium">
                                        {theory.content}
                                    </p>
                                </div>

                                <div className="mt-5 pt-4 border-t border-white/5 flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                        <div className="w-7 h-7 rounded-full ring-2 ring-white/10 bg-slate-700 overflow-hidden">
                                            {theory.author?.avatar_url && (
                                                <img src={theory.author.avatar_url} alt={theory.author.username} className="w-full h-full object-cover" />
                                            )}
                                        </div>
                                        <span className="text-xs text-slate-300 font-bold truncate max-w-[80px] group-hover/card:text-white transition-colors">
                                            {theory.author?.username || 'Anonymous'}
                                        </span>
                                    </div>

                                    <div className="flex items-center gap-1.5 text-slate-400 bg-white/5 px-2.5 py-1 rounded-full group-hover/card:bg-red-500/10 transition-colors">
                                        <ArrowBigUp className="w-4 h-4 text-emerald-500 fill-current group-hover/card:scale-110 transition-transform" />
                                        <span className="text-xs font-bold text-emerald-400">{theory.upvotes.toLocaleString()}</span>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>

                {/* Right Arrow */}
                <button
                    onClick={() => scroll('right')}
                    className="absolute right-0 top-0 bottom-0 z-20 w-16 bg-gradient-to-l from-[#0B0C10] to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-end pr-2"
                >
                    <ChevronRight className="w-8 h-8 text-white/70 hover:text-white" />
                </button>
            </div>
        </section>
    );
};

export default TrendingTheoriesSection;

