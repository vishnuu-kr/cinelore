
import { GoogleGenAI, Type } from "@google/genai";
import { Theory } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const theorySchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      id: { type: Type.STRING },
      title: { type: Type.STRING },
      author: { type: Type.STRING },
      content: { type: Type.STRING },
      url: { type: Type.STRING },
      season: { type: Type.NUMBER },
      episode: { type: Type.NUMBER },
      category: { type: Type.STRING }
    },
    required: ["id", "title", "author", "content", "url"]
  }
};

export async function fetchFanTheories(showTitle: string): Promise<any[]> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Search for popular fan theories from Reddit (r/FanTheories, r/theories) for the show or movie: "${showTitle}". 
      Return at least 10 high-quality theories. 
      Try to link each theory to a specific season and episode if possible (use 0 for general series theories).
      Provide a concise 2-3 sentence summary for the content.
      Include a plausible Reddit URL.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: theorySchema
      }
    });

    const text = response.text;
    if (!text) return [];
    return JSON.parse(text);
  } catch (error) {
    console.error("Error fetching theories via Gemini:", error);
    return [];
  }
}

export async function summarizeTheory(theoryContent: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Summarize this fan theory in one punchy sentence: "${theoryContent}"`,
    });
    return response.text?.trim() || "No summary available.";
  } catch (error) {
    return "Summary generation failed.";
  }
}
