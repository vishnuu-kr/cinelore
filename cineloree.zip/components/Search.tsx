﻿
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Show } from '../types';
import { searchShows, getFullPosterUrl } from '../services/tmdbService';
import { searchManga } from '../services/mangaService';
import { Search as SearchIcon, ArrowUpRight, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface SearchProps {
  onSelect: (show: Show) => void;
}

const Search: React.FC<SearchProps> = ({ onSelect }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Show[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  // Simplified pagination for combined search (just page 1 for now or endless scroll if complex)
  // Implementing combined pagination is tricky, so we'll stick to simple combined search for page 1 first
  // or parallel requests.
  const [page, setPage] = useState(1);
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);

  const performSearch = useCallback(async (searchQuery: string) => {
    setIsSearching(true);

    // Run both searches in parallel
    const [tmdbData, mangaData] = await Promise.all([
      searchShows(searchQuery, 1),
      searchManga(searchQuery)
    ]);

    // Combine and shuffle/sort? Just merge for now.
    const combined = [...tmdbData.results, ...mangaData];

    // Sort by popularity or relevance if possible, or just interleave? 
    // TMDB results are usually better sorted. Jikan relevance is okay.
    // Let's just use them as is.

    setResults(combined);
    setIsSearching(false);
    setShowDropdown(true);
  }, []);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      setShowDropdown(false);
      return;
    }

    const delayDebounceFn = setTimeout(() => {
      performSearch(query);
    }, 500); // 500ms debounce

    return () => clearTimeout(delayDebounceFn);
  }, [query, performSearch]);


  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative w-full group">
      {/* Cinematic Search Container */}
      <div className="relative z-20 rounded-xl transition-all duration-500 bg-[#0a0a0a]/60 backdrop-blur-xl border border-white/5 group-focus-within:border-white/10 group-hover:border-white/10 overflow-hidden">

        {/* Animated Accent Line */}
        <div className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-red-500 to-transparent scale-x-0 group-focus-within:scale-x-100 transition-transform duration-700 ease-out" />

        <div className="flex items-center pl-7">
          <div className="relative hidden sm:flex items-center gap-3 mr-4 select-none">
            <span className="text-[9px] font-black text-red-400/60 uppercase tracking-[0.2em]">Cmd</span>
            <div className="w-[1px] h-4 bg-white/10" />
          </div>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Initialize neural search..."
            className="w-full bg-transparent text-white text-lg py-6 outline-none placeholder-slate-600 font-light tracking-wide caret-red-400"
          />
        </div>

        <div className="absolute right-6 top-1/2 -translate-y-1/2 flex items-center space-x-4 pointer-events-none">
          <AnimatePresence mode="wait">
            {isSearching ? (
              <motion.div
                key="searching"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="flex items-center space-x-2"
              >
                <span className="text-[8px] text-red-400 uppercase tracking-widest font-black animate-pulse">Syncing</span>
                <Loader2 className="h-4 w-4 text-red-400 animate-spin" />
              </motion.div>
            ) : (
              <motion.div
                key="idle"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-3"
              >
                <div className="px-2 py-1 rounded-lg border border-white/5 bg-white/5 group-focus-within:border-red-500/30 transition-colors">
                  <SearchIcon className="h-3.5 w-3.5 text-slate-500 group-focus-within:text-white transition-colors" />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <AnimatePresence>
        {showDropdown && results.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.2 }}
            className="absolute w-full mt-2 bg-[#1a1b26]/95 border border-white/5 rounded-xl overflow-hidden z-50 backdrop-blur-xl"
          >
            <div className="p-2 max-h-[28rem] overflow-y-auto custom-scrollbar">
              {results.map((show) => (
                <button
                  key={`${show.type}-${show.id}`}
                  onClick={() => {
                    onSelect(show);
                    setShowDropdown(false);
                    setQuery('');
                  }}
                  className="w-full flex items-center p-3 hover:bg-white/10 rounded-2xl transition-all text-left group/item items-start gap-4"
                >
                  <div className="relative shrink-0">
                    <img
                      src={getFullPosterUrl(show.posterPath)}
                      alt={show.title}
                      className="w-12 h-16 object-cover rounded shadow-sm bg-slate-800"
                      onError={(e) => (e.currentTarget.src = "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?q=80&w=200")}
                    />
                    {show.type === 'movie' && (
                      <div className="absolute -bottom-2 -right-2 px-1.5 py-0.5 bg-blue-500 text-[8px] font-bold text-white rounded uppercase">
                        movie
                      </div>
                    )}
                    {show.type === 'tv' && (
                      <div className="absolute -bottom-2 -right-2 px-1.5 py-0.5 bg-violet-500 text-[8px] font-bold text-white rounded uppercase">
                        tv
                      </div>
                    )}
                    {show.type === 'manga' && (
                      <div className="absolute -bottom-2 -right-2 px-1.5 py-0.5 bg-emerald-500 text-[8px] font-bold text-white rounded uppercase">
                        manga
                      </div>
                    )}
                  </div>
                  <div className="flex-grow min-w-0 pt-1">
                    <div className="flex justify-between items-start">
                      <h3 className="text-white font-medium text-base truncate pr-2 group-hover/item:text-red-300 transition-colors">{show.title}</h3>
                      <ArrowUpRight className="w-3.5 h-3.5 text-white/20 group-hover/item:text-white/50" />
                    </div>
                    <p className="text-slate-500 text-xs line-clamp-2 mt-1 leading-relaxed">{show.overview}</p>
                  </div>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Search;

